const MODULE_NAME = 'mobile-token-movement-revived'
const CONTROLS_TEMPLATE_PATH = `./modules/${MODULE_NAME}/templates/mobile-token-movement-controls.html`;
const VIEWPOINT_PAN_THRESHOLD_MULTIPLIER = 2;
const MIN_WIDTH_SETTING_NAME = 'min-width';
const MIN_HEIGHT_SETTING_NAME = 'min-height';
const DEBUG_MESSAGES_SETTING_NAME = 'debug-messages';
