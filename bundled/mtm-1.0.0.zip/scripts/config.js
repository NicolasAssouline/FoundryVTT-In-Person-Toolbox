export const MODULE_NAME = 'mobile-token-movement'
export const MODULE_TITLE = 'Mobile Token Movement'
export const MODULE_LAYER = 'MobileTokenMovementLayer'
export const SETTINGS = {
  GlobalData: 'global-data',
  PlayerData: 'player-data'
}
