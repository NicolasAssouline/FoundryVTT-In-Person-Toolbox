# FoundryVTT Mobile Token Movement

Use your mobile device to control your token. Useful for in-person games with a public scene monitor using the module Monk's Common Display.
